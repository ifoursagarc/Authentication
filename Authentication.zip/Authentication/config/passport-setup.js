const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const FacebookStrategy = require('passport-facebook').Strategy;

const User = require("../model/user");

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser((id, done) => {
    User.findById(id).then((user) => {
        done(null, user);
    });

});

const keys = require("./keys");

passport.use(
    new GoogleStrategy({

        callbackURL: '/auth/google/redirect',
        clientID: keys.google.clientID,
        clientSecret: keys.google.clientSecret
    }, (accessToken, refreshToken, profile, done) => {

        console.log(profile);
        User.findOne({ googleID: profile.id })
            .then((currentUser) => {
                if (currentUser) {
                    console.log("user is:", currentUser);
                    done(null, currentUser);
                }
                else {

                    new User({
                        username: profile.displayName,
                        googleID: profile.id,
                        thumbnail: profile._json.picture

                    }).save()
                        .then((newUser) => {
                            console.log('new user created:' + newUser);
                            done(null, newUser);
                        });

                }
            });

    })
);

passport.use(new FacebookStrategy({
    clientID: keys.facebook.appID,
    clientSecret: keys.facebook.appSecret,
    callbackURL: "https://linq3.localhost.run/auth/facebook/redirect"
},
    (accessToken, refreshToken, profile, cb) => {

        console.log(profile);
        User.findOne({ facebookID: profile.id })
            .then((currentUser) => {
                if (currentUser) {
                    console.log("user is:", currentUser);
                    cb(null, currentUser);
                }
                else {

                    new User({
                        userName: profile.displayName,
                        facebookID: profile.id,
                        //thumbnail:profile._json.picture

                    }).save()
                        .then((newUser) => {
                            console.log('new user created:' + newUser);
                            cb(null, newUser);
                        });

                }
            });

    })
);