module.exports = {
    google: {
        clientID: "879399506-vlp0ph4bdkkmilfrh3rjb0meu8mkhcjj.apps.googleusercontent.com",
        clientSecret: "8MKi6hFF_wp3b-3sBf6K9yqg"
    }

    , mongodb: {
        dbURI: "mongodb://localhost:27017"
    },
    session: {
        cookieKey: 'sagarchavada'
    },
    facebook: {
        appID: '2361764474105849',
        appSecret: 'dfd944b1191cbedee6261f6c5687fb6b'
    }
};