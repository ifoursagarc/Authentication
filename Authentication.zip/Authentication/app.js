const express = require("express");
const app = express();
const authRoute = require('./routes/auth-routes');
//const authgoogleRoute = require('./routes/auth-google-routes');
const profileRoute = require('./routes/profile');
const port = process.env.PORT || 4000;
const passportSetup = require("./config/passport-setup");
const mongoose = require("mongoose");
const keys = require("./config/keys");
const cookieSession = require("cookie-session");
const passport = require("passport");

app.set('view engine', 'ejs');
app.set('views', './view');


mongoose.connect(keys.mongodb.dbURI, () => {
    console.log("connect to mongodb");
});


app.use(cookieSession({
    maxAge: 24 * 60 * 60 * 1000,
    keys: [keys.session.cookieKey]
}));

app.use(passport.initialize());
app.use(passport.session());


app.use('/auth', authRoute);
//app.use('/googleauth', authgoogleRoute);
app.use('/profile', profileRoute);

app.get('/auth/google', passport.authenticate('google'));

app.get('/auth/google/redirect',
    passport.authenticate('google', {
        successRedirect: '/',
        failureRedirect: '/login'
    }));

app.get('/', (req, res) => {
    res.render('home', {
        user: req.user
    });
});

app.listen(port, () => {
    console.log(`sever port listeninig on ${port}`);
});
