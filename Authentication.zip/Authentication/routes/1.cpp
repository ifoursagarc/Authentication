#include <iostream>
#include <limits>
using namespace std;
int main()
{
    cout << boolalpha;
    cout << numeric_limits<int>::has - infinity << '\n';
    return 0;
}
