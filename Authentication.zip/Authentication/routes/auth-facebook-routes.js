const router = require("express").Router();
const passport = require("passport");


router.get('/FacebookLogin', (req, res) => {
    res.render('login', { user: req.user });
});

router.get('/auth/facebook', passport.authenticate('facebook', {
    sscope: ['publish_actions']
}));

// router.get('/auth/facebook/callback',
//   passport.authenticate('facebook', { successRedirect: '/',
//                                       failureRedirect: '/login' }));

router.get('/facebook/redirect')

router.get('/facebook/redirect', passport.authenticate('facebook'), (req, res) => {

    //res.send( req.user);
    res.redirect('/facebookprofile/');
});

router.get('/facebooklogout', (req, res) => {
    // res.send('logging out');
    req.logout();
    res.redirect("/");
});


module.exports = router;